import React from "react";

const Head = () => {
  return <h1>Calculate BMI</h1>;
};

export default Head;
