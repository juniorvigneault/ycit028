import React from "react";

const Result = ({ state }) => {
  return <p id="result">{state.result}</p>;
};

export default Result;
