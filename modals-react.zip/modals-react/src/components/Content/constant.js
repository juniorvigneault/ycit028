const contents = [
  {
    id: "1",
    title: "Welcome!",
    content:
      "Lorem, ipsum dolor sit amet consectetur adipisicing elit. Quibusdam deleniti eveniet in odio magnam. Obcaecati, ullam culpa ipsam sequibnisi eos, corrupti animi repellat aliquam, deleniti facere quidemitaque eligendi? ",
  },
  {
    id: "2",
    title: "Are you sure?",
    content: "Please accept cookies before using this website!",
  },
  {
    id: "3",
    title: "",
    content: "",
  },
  {
    id: "4",
    title: "",
    content: "",
  },
  {
    id: "5",
    title: "",
    content: "",
  },
];

export default contents;
